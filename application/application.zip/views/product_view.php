<!-- START PAGE CONTENT -->
<div class="content ">
    <!-- START JUMBOTRON -->
    <div class="jumbotron" data-pages="parallax">
        <div class=" container-fluid   container-fixed-lg sm-p-l-0 sm-p-r-0">
            <div class="inner">
                <!-- START BREADCRUMB -->
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active"><?= $title; ?></li>
                </ol>
                <!-- END BREADCRUMB -->
            </div>
        </div>
    </div>
    <!-- END JUMBOTRON -->

    <!-- START CONTAINER FLUID -->
    <div class="container-fluid container-fixed-lg">
        <!-- BEGIN PlACE PAGE CONTENT HERE -->
        <div class="card card-transparent">
            <div class="card-header ">
                <!-- <div class="card-title">Transaction List
                </div> -->
                <div class="pull-left">
                    <button class="btn btn-success" data-toggle="modal" data-target="#myModalAdd">Add New</button>
                </div>
                <div class="pull-right">
                    <div class="col-xs-12">
                        <input type="text" id="search-table" class="form-control pull-right" placeholder="Search">
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="card-body">
                <table class="table table-hover table-responsive-block" id="product_table">
                    <thead>
                        <tr>
                            <th style="width: 20%">Code</th>
                            <th style="width: 20%">Product Name</th>
                            <th style="width: 15%">Price</th>
                            <th style="width: 20%">Category</th>
                            <th style="width: 15%">Stock</th>
                            <th style="width: 10%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        foreach ($data->result_array() as $a) :
                            $no++;
                            $id = $a['product_code'];
                            $name = $a['name'];
                            $price = $a['price'];
                            // $kat_id = $a['barang_kategori_id'];
                            $category = $a['category'];
                            $stock = $a['stock'];
                            ?>
                            <tr>
                                <td><?php echo $id; ?></td>
                                <td><?php echo $name; ?></td>
                                <td><?php echo $price; ?></td>
                                <td><?php echo $category; ?></td>
                                <td><?php echo $stock; ?></td>
                                <td>
                                    <div class="dropdown pull-right d-none d-lg-block d-xl-block">
                                        <a href="#" class="btn btn-primary btn-sm btn-rounded" data-toggle="dropdown" aria-expanded="false"><i class="pg-more"></i></a>
                                        <div class="dropdown-menu dropdown-menu-right action-dropdown">
                                            <a class="dropdown-item" href="#modalHapusPelanggan<?php echo $id ?>" data-toggle="modal" title="Hapus"><i class="fa fa-trash-o"></i> Delete</a>
                                            <a class="dropdown-item" href="#modalEditPelanggan<?php echo $id ?>" data-toggle="modal" title="Edit"><i class="fa fa-pencil"></i> Edit</a>
                                            <!-- <a class="dropdown-item" href="#" data-toggle="modal" data-target="#" onclick="modal_status(13)"><i class="fa fa-leaf"></i> Status</a> -->
                                        </div>
                                    </div>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- END PLACE PAGE CONTENT HERE -->
</div>
<!-- END PAGE CONTENT -->

<!-- ============ MODAL ADD =============== -->
<div class="modal fade" id="myModalAdd" tabindex="-1" role="dialog" aria-hidden="false">
    <div class="modal-dialog ">
        <div class="modal-content-wrapper">
            <div class="modal-content">
                <div class="modal-header clearfix text-left">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="pg-close fs-14"></i>
                    </button>
                    <h5>Add <span class="semi-bold">Product</span></h5>
                    <!-- <p class="p-b-10">We need payment information inorder to process your order</p> -->
                </div>

                <form method="post" action="<?php echo base_url() . 'product/add_product' ?>">
                    <div class="modal-body">
                        <div class="form-group-attached">
                            <div class="form-group form-group-default">
                                <label>Code</label>
                                <input type="text" name="product_code" class="form-control" value="<?= $productcode; ?>" readonly>
                            </div>
                            <div class="row clearfix">
                                <div class="col-md-6">
                                    <div class="form-group form-group-default">
                                        <label>Name</label>
                                        <input type="text" name="name" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group form-group-default form-group-default-selectFx">
                                        <label>Category</label>
                                        <select name="category" class="cs-select cs-skin-slide cs-transparent form-control" data-init-plugin="cs-select">
                                            <?php foreach ($categories->result() as $row) : ?>
                                                <option value="<?php echo $row->categories_id; ?>"><?php echo $row->category; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row clearfix">
                                <div class="col-md-6">
                                    <div class="form-group form-group-default">
                                        <label>Price</label>
                                        <input type="text" name="price" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group form-group-default">
                                        <label>Stock</label>
                                        <input type="text" name="stock" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                        <button class="btn btn-info">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- ============ MODAL EDIT =============== -->
<?php
foreach ($data->result_array() as $a) {
    $product_code = $a['product_code'];
    $name = $a['name'];
    $categories_id = $a['product_categories_id'];
    $category = $a['category'];
    $price = $a['price'];
    $stock = $a['stock'];
    ?>
    <div id="modalEditPelanggan<?php echo $product_code ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content-wrapper">
                <div class="modal-content">
                    <div class="modal-header clearfix text-left">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="pg-close fs-14"></i>
                        </button>
                        <h5>Edit <span class="semi-bold">Product</span></h5>
                    </div>

                    <form method="post" action="<?php echo base_url() . 'product/edit_product' ?>">
                        <div class="modal-body">

                            <div class="form-group-attached">
                                <div class="form-group form-group-default">
                                    <label>Code</label>
                                    <input type="text" name="product_code" class="form-control" value="<?= $product_code; ?>" readonly>
                                </div>
                                <div class="row clearfix">
                                    <div class="col-md-6">
                                        <div class="form-group form-group-default">
                                            <label>Name</label>
                                            <input type="text" name="name" value="<?php echo $name; ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group form-group-default form-group-default-selectFx">
                                            <label>Category</label>
                                            <select name="category" class="cs-select cs-skin-slide cs-transparent form-control" data-init-plugin="cs-select">
                                                <option value="<?php echo $categories_id; ?>"> <?php echo $category; ?> </option>
                                                <?php foreach ($categories->result() as $row) : ?>
                                                    <option value="<?php echo $row->categories_id; ?>"><?php echo $row->category; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row clearfix">
                                    <div class="col-md-6">
                                        <div class="form-group form-group-default">
                                            <label>Price</label>
                                            <input type="text" name="price" value="<?php echo $price; ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group form-group-default">
                                            <label>Stock</label>
                                            <input type="text" name="stock" value="<?php echo $stock; ?>" class="form-control" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                            <button type="submit" class="btn btn-info">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php
}
?>

<!-- ============ MODAL HAPUS =============== -->
<?php
foreach ($data->result_array() as $a) {
    $product_code = $a['product_code'];
    $name = $a['name'];
    $category = $a['category'];
    $price = $a['price'];
    $stock = $a['stock'];
    ?>
    <div id="modalHapusPelanggan<?php echo $product_code ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h3 class="modal-title" id="myModalLabel">Hapus Barang</h3>
                </div>
                <form class="form-horizontal" method="post" action="<?php echo base_url() . 'product/delete_product' ?>">
                    <div class="modal-body">
                        <p>Yakin mau menghapus data barang ini..?</p>
                        <input name="product_code" type="hidden" value="<?php echo $product_code; ?>">
                    </div>
                    <div class="modal-footer">
                        <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                        <button type="submit" class="btn btn-primary">Hapus</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php
}
?>

<!-- Modal Update Produk-->
<!-- <form id="add-row-form" action=" " method="post">
    <div class="modal fade" id="ModalUpdate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Update Produk</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" name="kode_barang" class="form-control" placeholder="Kode Barang" required>
                    </div>
                    <div class="form-group">
                        <input type="text" name="nama_barang" class="form-control" placeholder="Nama Barang" required>
                    </div>
                    <div class="form-group">
                        <select name="kategori" class="form-control" placeholder="Kode Barang" required>
                          
                                <option value=""></option>
                            
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="text" name="harga" class="form-control" placeholder="Harga" required>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" id="add-row" class="btn btn-success">Update</button>
                </div>
            </div>
        </div>
    </div>
</form> -->

<!-- Modal Hapus Produk-->
<!-- <form id="add-row-form" action="" method="post">
    <div class="modal fade" id="ModalHapus" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Hapus Produk</h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="kode_barang" class="form-control" placeholder="Kode Barang" required>
                    <strong>Anda yakin mau menghapus record ini?</strong>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" id="add-row" class="btn btn-success">Hapus</button>
                </div>
            </div>
        </div>
    </div>
</form> -->