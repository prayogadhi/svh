<!-- START PAGE CONTENT -->
<div class="content ">
    <!-- START JUMBOTRON -->
    <div class="jumbotron" data-pages="parallax">
        <div class=" container-fluid   container-fixed-lg sm-p-l-0 sm-p-r-0">
            <div class="inner">
                <!-- START BREADCRUMB -->
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active"><?= $title; ?></li>
                </ol>
                <!-- END BREADCRUMB -->
            </div>
        </div>
    </div>
    <!-- END JUMBOTRON -->

    <!-- START CONTAINER FLUID -->
    <div class="container-fluid container-fixed-lg">
        <!-- BEGIN PlACE PAGE CONTENT HERE -->
        <div class="card card-transparent">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-3">
                        <div id="card-linear-color" class="card card-default">
                            <div class="card-body">
                                <form role="form" id="form-sales">
                                    <p class="font-montserrat fs-11 all-caps bold m-t-10">Informasi Dasar</p>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group form-group-default disabled" style="background: #fff; color: #626262;">
                                                <label>Nomor Transaksi</label>
                                                <input type="text" class="form-control" style="color: #000;" value="Cart#" id="text_id_cart" disabled="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group form-group-default input-group">
                                                <div class="form-input-group">
                                                    <label>Tanggal Order</label>
                                                    <input type="text" class="form-control" placeholder="Pick a date" id="text_order_date">
                                                </div>
                                                <div class="input-group-append ">
                                                    <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group form-group-default form-group-default-select2 required">
                                                <label class="">Order from</label>
                                                <select class="full-width" placeholder="Pilih platform yang digunakan" data-init-plugin="select2" id="select_platform">
                                                    <option value="Lazada">Lazada</option>
                                                    <option value="Shoopee">Shoopee</option>
                                                    <option value="Tokopedia">Tokopedia</option>
                                                    <option value="Bukalapak">Bukalapak</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="font-montserrat fs-11 all-caps bold m-t-10">Informasi Customer</p>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group form-group-default">
                                                <label>Nama Customer</label>
                                                <input type="text" class="form-control" id="text_member_name" value="Hidayat" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group form-group-default">
                                                <label>Nomor Telepon/HP</label>
                                                <input type="text" class="form-control" id="text_member_phone" pattern="\d+" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group form-group-default">
                                                <label>E-mail</label>
                                                <input type="email" class="form-control" id="text_email_member" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group form-group-default">
                                                <label>Alamat</label>
                                                <input type="text" class="form-control" id="text_member_address" value="jln. sarimanis vii blok 13" />
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div id="card-circular-color" class="card card-default">
                            <div class="card-header  ">
                                <div class="card-title">Item List
                                </div>
                            </div>
                            <div class="card-body">
                                <form action="<?= base_url() . 'sales/add_to_cart' ?>" method="post">
                                    <div class="row">
                                        <div class="col-md-4" style="padding-top: 0.5px; padding-right: 0px;">
                                            <div class="form-group form-group-default input-group typehead">
                                                <div class="form-input-group">
                                                    <label>Product Code</label>
                                                    <input type="text" name="product_code" class="form-control typeahead" id="product_code" value="" placeholder="Ketikan kode produk">
                                                </div>
                                                <div class="input-group-append ">
                                                    <span class="input-group-text"><i class="fa fa-barcode"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-8" id="detail_barang">
                                        </div>
                                    </div>
                                </form>
                                <table class="table table-condensed no-footer" id="tableCart">
                                    <thead>
                                        <tr>
                                            <th style="width:5%"></th>
                                            <th style="width:20%">Product Code</th>
                                            <th style="width:20%">Nama Barang</th>
                                            <th style="width:15%">Price(Rp)</th>
                                            <th style="width:15%">Diskon(Rp)</th>
                                            <th style="width:9%">Qty</th>
                                            <th style="width:16%">Sub Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1; ?>
                                        <?php foreach ($this->cart->contents() as $items) : ?>
                                            <?php echo form_hidden($i . '[rowid]', $items['rowid']); ?>
                                            <tr>
                                                <td><a href="<?php echo base_url() . 'sales/remove/' . $items['rowid']; ?>" class="remove-item"><i class="pg-close"></i></a></td>
                                                <td><?= $items['id']; ?></td>
                                                <td><?= $items['name']; ?></td>
                                                <td><?php echo number_format($items['amount']); ?></td>
                                                <td><?php echo number_format($items['disc']); ?></td>
                                                <td><?php echo number_format($items['qty']); ?></td>
                                                <td><?php echo number_format($items['subtotal']); ?></td>
                                            </tr>
                                            <?php $i++; ?>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <form action="<?php echo base_url() . 'sales/simpan_penjualan' ?>" method="post">
                                    <!-- <div class="row m-t-40">
                                        <div class="col-md-9 m-b-25">
                                            <div class="form-group-attached">
                                                <div class="row clearfix">
                                                    <div class="col-md-4">
                                                        <div class="form-group form-group-default disabled" style="background: #fff; color: #626262;">
                                                            <label>Total</label>
                                                            <input type="text" class="form-control bold autonumeric" data-a-sign="Rp " data-a-dec="," data-a-sep="." style="color: red;" value="<?php echo number_format($this->cart->total()); ?>" id="text_total_cart" disabled="">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group form-group-default">
                                                            <label class="fade">Special Diskon</label>
                                                            <input type="text" data-a-sign=" %" data-p-sign="s" id="text_diskon_cart" value="0" class="autonumeric form-control calculate_pay">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group form-group-default">
                                                            <label class="fade">Ongkos Kirim</label>
                                                            <input type="text" data-a-sign="Rp " data-a-dec="," data-a-sep="." id="text_ongkos_kirim" value="0" class="autonumeric form-control calculate_pay">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 text-center">
                                            <h5 class="font-montserrat all-caps small no-margin bold">Grand Total</h5>
                                            <h4 class="no-margin text-primary bold autonumeric" data-a-sign="Rp " data-a-dec="," data-a-sep="." id="text_grand_total">Rp 0,00</h4>
                                        </div>
                                    </div> -->

                                    <table>
                                        <tr>
                                            <td style="width:760px;" rowspan="2"><button type="submit" class="btn btn-info btn-lg"> Simpan</button></td>
                                            <th style="width:140px;">Total Belanja(Rp)</th>
                                            <th style="text-align:right;width:140px;"><input type="text" name="total2" value="<?php echo number_format($this->cart->total()); ?>" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" readonly></th>
                                            <input type="hidden" id="total" name="total" value="<?php echo $this->cart->total(); ?>" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" readonly>
                                        </tr>
                                        <tr>
                                            <th>Tunai(Rp)</th>
                                            <th style="text-align:right;"><input type="text" id="jml_uang" name="jml_uang" class="jml_uang form-control input-sm" style="text-align:right;margin-bottom:5px;" required></th>
                                            <input type="hidden" id="jml_uang2" name="jml_uang2" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" required>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <th>Kembalian(Rp)</th>
                                            <th style="text-align:right;"><input type="text" id="kembalian" name="kembalian" class="form-control input-sm" style="text-align:right;margin-bottom:5px;" required></th>
                                        </tr>

                                    </table>
                                </form>
                                <hr />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END PLACE PAGE CONTENT HERE -->
    </div>
</div>
<!-- END PAGE CONTENT -->

<!-- ============ MODAL ADD =============== -->
<div class="modal fade" id="largeModal" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="modal-title" id="myModalLabel">Data Barang</h3>
            </div>
            <div class="modal-body">
                <table class="table table-bordered" style="font-size:11px;" id="sales_table">
                    <thead>
                        <tr>
                            <th>Kode Barang</th>
                            <th>Nama Barang</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        foreach ($data->result_array() as $a) :
                            $no++;
                            $id = $a['product_code'];
                            $nm = $a['name'];
                            $price = $a['price'];
                            $stok = $a['stock'];
                            // $kat_id = $a['barang_kategori_id'];
                            // $kat_nama = $a['kategori_nama'];
                            ?>
                            <tr>
                                <td><?php echo $id; ?></td>
                                <td><?php echo $nm; ?></td>
                                <td><?php echo 'Rp ' . number_format($price); ?></td>
                                <td><?php echo $stok; ?></td>
                                <td>
                                    <form action="<?php echo base_url() . 'sales/add_to_cart' ?>" method="post">
                                        <input type="hidden" name="product_code" value="<?php echo $id; ?>">
                                        <input type="hidden" name="name" value="<?php echo $nm; ?>">
                                        <input type="hidden" name="stock" value="<?php echo $stok; ?>">
                                        <input type="hidden" name="price" value="<?php echo number_format($price); ?>">
                                        <input type="hidden" name="discount" value="0">
                                        <input type="hidden" name="qty" value="1" required>
                                        <button type="submit" class="btn btn-xs btn-info" title="Pilih"><span class="fa fa-edit"></span> Pilih</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="modal-footer">
                <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
            </div>
        </div>
    </div>
</div>