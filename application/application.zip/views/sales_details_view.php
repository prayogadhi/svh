<?php
error_reporting(0);
$b = $product->row_array();
?>

<table>
    <tr>
        <td style="width: 27%;">
            <div class="form-group form-group-default input-group">
                <div class="form-input-group">
                    <label>Nama Barang</label>
                    <input type="text" name="name" value="<?php echo $b['name']; ?>" class="form-control" readonly>
                </div>
            </div>
        </td>
        <td style="width: 12.5%;">
            <div class="form-group form-group-default input-group">
                <div class="form-input-group">
                    <label>Stock</label>
                    <input type="text" name="stock" value="<?php echo $b['stock']; ?>" class="form-control" readonly>
                </div>
            </div>
        </td>
        <td style="width: 20%;">
            <div class="form-group form-group-default input-group">
                <div class="form-input-group">
                    <label>Harga</label>
                    <input type="text" name="price" value="<?php echo number_format($b['price']); ?>" class="form-control" readonly>
                </div>
            </div>
        </td>
        <td style="width: 20%;">
            <div class="form-group form-group-default input-group">
                <div class="form-input-group">
                    <label>Discount</label>
                    <input type="number" name="disc" id="disc" value="0" min="0" class="form-control">
                </div>
            </div>
        </td>
        <td style="width: 10.5%;">
            <div class="form-group form-group-default input-group">
                <div class="form-input-group">
                    <label>Qty</label>
                    <input type="number" name="qty" id="qty" value="1" min="1" max="<?php echo $b['stock']; ?>" class="form-control">
                </div>
            </div>
        </td>
        <td style="width: 10%; padding-left: 5px; padding-bottom: 12px;"><button type="submit" class="btn btn-rounded btn-success btn-animated from-top fa fa-check" style="padding: 6px 12px;"><span><i class="fa fa-plus"></i></span></button></td>
    </tr>
</table>