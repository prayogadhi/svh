            <!-- START COPYRIGHT -->
            <!-- START CONTAINER FLUID -->
            <div class=" container-fluid  container-fixed-lg footer">
                <div class="copyright sm-text-center">
                    <p class="small no-margin pull-left sm-pull-reset">
                        <span class="hint-text">&copy; <?= date('Y'); ?> </span>
                        <span class="hint-text">Memento Project</span>
                        <!-- <span class="hint-text">All rights reserved. </span> -->
                    </p>
                    <p class="small no-margin pull-right sm-pull-reset">
                        <span class="font-montserrat">SVH</span>
                        <span class="hint-text"> management site</span>
                    </p>
                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- END COPYRIGHT -->
            </div>
            <!-- END PAGE CONTENT WRAPPER -->
            </div>
            <!-- END PAGE CONTAINER -->

            <!-- BEGIN VENDOR JS -->
            <script src="<?= base_url('vendor/'); ?>assets/plugins/pace/pace.min.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/jquery/jquery-3.2.1.min.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/modernizr.custom.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/popper/umd/popper.min.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript">
            </script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/jquery/jquery-easy.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript">
            </script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/jquery-ios-list/jquery.ioslist.min.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/jquery-actual/jquery.actual.min.js"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js"></script>
            <script type="text/javascript" src="<?= base_url('vendor/'); ?>assets/plugins/select2/js/select2.full.min.js">
            </script>
            <script type="text/javascript" src="<?= base_url('vendor/'); ?>assets/plugins/classie/classie.js"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/switchery/js/switchery.min.js" type="text/javascript">
            </script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/summernote/js/summernote.min.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/moment/moment.min.js"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
            <!-- END VENDOR JS -->

            <!-- START DATATABLE JS -->
            <script src="<?= base_url('vendor/'); ?>assets/plugins/jquery-datatable/media/js/jquery.dataTables.min.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/jquery-datatable/extensions/TableTools/js/dataTables.tableTools.min.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/jquery-datatable/media/js/dataTables.bootstrap.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/jquery-datatable/extensions/Bootstrap/jquery-datatable-bootstrap.js" type="text/javascript"></script>
            <script type="text/javascript" src="<?= base_url('vendor/'); ?>assets/plugins/datatables-responsive/js/datatables.responsive.js"></script>
            <script type="text/javascript" src="<?= base_url('vendor/'); ?>assets/plugins/datatables-responsive/js/lodash.min.js"></script>
            <!-- END DATATABLE JS -->

            <!-- START TYPEHEAD JS -->
            <script src="<?= base_url('vendor/'); ?>assets/plugins/bootstrap-typehead/typeahead.bundle.min.js"></script>
            <script src="https://twitter.github.io/typeahead.js/js/handlebars.js"></script>
            <script src="<?= base_url('vendor/'); ?>assets/plugins/bootstrap-typehead/typeahead.jquery.min.js"></script>
            <!-- END TYPEHEAD JS -->

            <script src="<?php echo base_url() . 'assets/js/jquery.price_format.min.js' ?>"></script>
            <script src="<?php echo base_url() . 'assets/js/moment.js' ?>"></script>

            <!-- BEGIN CORE TEMPLATE JS -->
            <script src="<?= base_url('vendor/'); ?>pages/js/pages.js"></script>
            <script src="<?= base_url('vendor/'); ?>assets/js/datatables.js" type="text/javascript"></script>
            <script src="<?= base_url('vendor/'); ?>assets/js/scripts.js" type="text/javascript"></script>
            <!-- END CORE TEMPLATE JS -->


            <!-- BEGIN FUNCTION SCRIPT -->

            <script>
                // $('.custom-file-input').on('change', function() {
                //     let fileName = $(this).val().split('\\').pop();
                //     $(this).next('.custom-file-label').addClass("selected").html(fileName);
                // });
                // $('.table-responsive').on('show.bs.dropdown', function() {
                //     $('.table-responsive').css("overflow", "inherit");
                // });

                // $('.table-responsive').on('hide.bs.dropdown', function() {
                //     $('.table-responsive').css("overflow", "auto");
                // })
            </script>

            <script type="text/javascript">
                $(document).ready(function() {
                    $('#mydata').DataTable();
                });
            </script>

            <script type="text/javascript">
                // var table = $('#product_table');

                // var settings = {
                //     "sDom": "<'table-responsive't><'row'<p i>>",
                //     "sPaginationType": "bootstrap",
                //     "destroy": true,
                //     "scrollCollapse": true,
                //     "oLanguage": {
                //         "sLengthMenu": "_MENU_ ",
                //         "sInfo": "Showing <b>_START_ to _END_</b> of _TOTAL_ entries"
                //     },
                //     "iDisplayLength": 5
                // };

                // table.dataTable();

                // $('#search-table-product').keyup(function() {
                //     table.fnFilter($(this).val());
                // });
                $(document).ready(function() {

                    var table = $('#product_table').DataTable({
                        "processing": true,
                        "order": [
                            [0, "desc"]
                        ],
                        "sDom": "<t><'row'<p i>>",
                        "sPaginationType": "bootstrap",
                        "destroy": true,
                        "scrollCollapse": true,
                        "iDisplayLength": 5,
                        //Set column definition initialisation properties.
                        "columnDefs": [{
                            "targets": [-1], //last column
                            "orderable": false, //set not orderable
                        }],
                    });

                    // $('#search-table').on('keyup click', function() {
                    //     table.column(0).search('^' + $(this).val() + '$', true);
                    //     if (table.page.info().recordsDisplay != 1) {
                    //         table.column(0).search('^' + $(this).val(), true);
                    //     }

                    //     table.draw();
                    // });

                    $('#search-table').keyup(function() {
                        table.search(this.value).draw();
                    });

                });
            </script>

            <!-- sales script -->
            <script type="text/javascript">
                $(function() {
                    $('#jml_uang').on("input", function() {
                        var total = $('#total').val();
                        var jumuang = $('#jml_uang').val();
                        var hsl = jumuang.replace(/[^\d]/g, "");
                        $('#jml_uang2').val(hsl);
                        $('#kembalian').val(hsl - total);
                    })

                });
            </script>
            <script type="text/javascript">
                $(document).ready(function() {
                    $('#sales_table').dataTable();
                });
            </script>
            <script type="text/javascript">
                $(function() {
                    $('.jml_uang').priceFormat({
                        prefix: '',
                        //centsSeparator: '',
                        centsLimit: 0,
                        thousandsSeparator: ','
                    });
                    $('#jml_uang2').priceFormat({
                        prefix: '',
                        //centsSeparator: '',
                        centsLimit: 0,
                        thousandsSeparator: ''
                    });
                    $('#kembalian').priceFormat({
                        prefix: '',
                        //centsSeparator: '',
                        centsLimit: 0,
                        thousandsSeparator: ','
                    });
                    $('.harjul').priceFormat({
                        prefix: '',
                        //centsSeparator: '',
                        centsLimit: 0,
                        thousandsSeparator: ','
                    });
                });
            </script>

            <script type="text/javascript">
                $(document).ready(function() {
                    $("#product_code").focus();
                    $("#product_code").on("input", function() {
                        var productcode = {
                            product_code: $(this).val()
                        };
                        $.ajax({
                            type: "POST",
                            url: "<?php echo base_url() . 'sales/get_barang'; ?>",
                            data: productcode,
                            success: function(msg) {
                                $('#detail_barang').html(msg);
                            }
                        });
                    });

                    $("#product_code").keypress(function(e) {
                        if (e.which == 13) {
                            $("#jumlah").focus();
                        }
                    });
                });
            </script>
            <!-- end sales script -->

            <script>
                $('#tableCart').DataTable({
                    "ordering": false,
                    "searching": false,
                    "paging": false,
                    "info": false
                });
            </script>

            <script>
                $(document).ready(function() {
                    var sample_data = new Bloodhound({
                        datumTokenizer: Bloodhound.tokenizers.obj.whitespace('value' + '&nbsp'),
                        queryTokenizer: Bloodhound.tokenizers.whitespace,
                        prefetch: '<?= base_url(); ?>product/fetch',
                        remote: {
                            url: '<?php echo base_url(); ?>product/fetch/%QUERY',
                            wildcard: '%QUERY'
                        }
                    });


                    $('.typeahead').typeahead(null, {
                        code: 'sample_data',
                        display: 'code',
                        source: sample_data,
                        limit: 10
                    });
                });
            </script>

            <!-- END FUNCTION SCRIPT -->

            <script>
                var elems = Array.prototype.slice.call(document.querySelectorAll('.switchery'));
                // Success color: #10CFBD
                elems.forEach(function(html) {
                    var switchery = new Switchery(html, {
                        color: '#10CFBD'
                    });
                });
            </script>

            <script>
                $('.form-check-input').on('change', function() {
                    const menuId = $(this).data('menu');
                    const roleId = $(this).data('role');

                    $.ajax({
                        url: "<?= base_url('admin/changeaccess'); ?>",
                        type: 'post',
                        data: {
                            menuId: menuId,
                            roleId: roleId
                        },
                        success: function() {
                            document.location.href = "<?= base_url('admin/roleaccess/')  ?>" + roleId;
                        }
                    });
                })
            </script>

            </body>

            </html>