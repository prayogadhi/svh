<!-- START PAGE CONTENT -->
<div class="content ">
    <!-- START JUMBOTRON -->
    <div class="jumbotron" data-pages="parallax">
        <div class=" container-fluid   container-fixed-lg sm-p-l-0 sm-p-r-0">
            <div class="inner">
                <!-- START BREADCRUMB -->
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active"><?= $title; ?></li>
                </ol>
                <!-- END BREADCRUMB -->
            </div>
        </div>
    </div>
    <!-- END JUMBOTRON -->

    <!-- START CONTAINER FLUID -->
    <div class="container-fluid container-fixed-lg">
        <!-- BEGIN PlACE PAGE CONTENT HERE -->
        <div class="card card-transparent">
            <div class="card-header ">
                <!-- <div class="card-title">Transaction List
                </div> -->
                <div class="pull-left">
                    <button class="btn btn-success" data-toggle="modal" data-target="#myModalAdd">Add New</button>
                </div>
                <div class="pull-right">
                    <div class="col-xs-12">
                        <input type="text" id="search-table" class="form-control pull-right" placeholder="Search">
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="card-body">
                <table class="table table-hover table-responsive-block" id="product_table">
                    <thead>
                        <tr>
                            <th style="width: 20%">Transaction ID</th>
                            <th style="width: 20%">Date</th>
                            <th style="width: 15%">Total Price</th>
                            <th style="width: 20%">Amount Paid</th>
                            <th style="width: 15%">Change Money</th>
                            <th style="width: 10%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        foreach ($data->result_array() as $a) :
                            $no++;
                            $id = $a['transaction_id'];
                            $date = $a['date'];
                            $price = $a['total_price'];
                            $amount = $a['amount_paid'];
                            $change = $a['change_money'];
                            ?>
                            <tr>
                                <td><?php echo $id; ?></td>
                                <td><?php echo $date; ?></td>
                                <td><?php echo $price; ?></td>
                                <td><?php echo $amount; ?></td>
                                <td><?php echo $change; ?></td>
                                <td>
                                    <div class="dropdown pull-right d-none d-lg-block d-xl-block">
                                        <a href="#" class="btn btn-primary btn-sm btn-rounded" data-toggle="dropdown" aria-expanded="false"><i class="pg-more"></i></a>
                                        <div class="dropdown-menu dropdown-menu-right action-dropdown">
                                            <a class="dropdown-item" href="#modalHapusPelanggan<?php echo $id ?>" data-toggle="modal" title="Hapus"><i class="fa fa-trash-o"></i> Delete</a>
                                            <a class="dropdown-item" href="#modalEditPelanggan<?php echo $id ?>" data-toggle="modal" title="Edit"><i class="fa fa-pencil"></i> Edit</a>
                                            <!-- <a class="dropdown-item" href="#" data-toggle="modal" data-target="#" onclick="modal_status(13)"><i class="fa fa-leaf"></i> Status</a> -->
                                        </div>
                                    </div>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- END PLACE PAGE CONTENT HERE -->
</div>
<!-- END PAGE CONTENT -->