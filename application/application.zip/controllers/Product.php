<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Product extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->model('category_model'); //load model product_model
        $this->load->model('product_model'); //load model product_model
    }
    function index()
    {
        $data['title'] = 'Product';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['menu'] = $this->db->get('user_menu')->result_array();
        $data['categories'] = $this->category_model->get_categories();
        $data['data'] = $this->product_model->tampil_barang();
        $data['productcode'] = $this->product_model->create_code();

        $this->load->helper('url');
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('product_view', $data);
        $this->load->view('templates/footer');
    }

    // $data['data'] = $this->m_barang->tampil_barang();
    // $data['kat'] = $this->m_kategori->tampil_kategori();
    // $data['kat2'] = $this->m_kategori->tampil_kategori();
    // $this->load->view('admin/v_barang', $data);

    function add_product()
    {
        // if ($this->session->userdata('akses') == '1') {
        $product_code = $this->input->post('product_code');
        $name = $this->input->post('name');
        $category = $this->input->post('category');
        $price = $this->input->post('price');
        $stock = $this->input->post('stock');
        $this->product_model->save_product($product_code, $name, $category, $price, $stock);

        redirect('product');
    }
    function edit_product()
    {
        // if ($this->session->userdata('akses') == '1') {

        $product_code = $this->input->post('product_code');
        $name = $this->input->post('name');
        $category = $this->input->post('category');
        $price = $this->input->post('price');
        $stock = $this->input->post('stock');
        $this->product_model->update_product($product_code, $name, $category, $price, $stock);
        redirect('product');
    }
    function delete_product()
    {
        $product_code = $this->input->post('product_code');
        $this->product_model->delete_product($product_code);
        redirect('product');
    }
    function fetch()
    {
        echo $this->product_model->fetch_data($this->uri->segment(3));
    }
}
