<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sales extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('category_model', 'category');
        $this->load->model('product_model', 'product');
        $this->load->model('sales_model', 'sales');
    }
    function index()
    {
        $data['title'] = 'Sales';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['menu'] = $this->db->get('user_menu')->result_array();
        $data['data'] = $this->product->tampil_barang();

        $this->load->helper('url');
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('sales_view', $data);
        $this->load->view('templates/footer');
        // if ($this->session->userdata('akses') == '1' || $this->session->userdata('akses') == '2') {
        //     $data['data'] = $this->m_barang->tampil_barang();
        //     $this->load->view('admin/v_penjualan', $data);
        // } else {
        //     echo "Halaman tidak ditemukan";
        // }
    }
    function get_barang()
    {
        $productcode = $this->input->post('product_code');
        $x['product'] = $this->product->get_barang($productcode);
        $this->load->view('sales_details_view', $x);
    }
    function add_to_cart()
    {
        $productcode = $this->input->post('product_code');
        $produk = $this->product->get_barang($productcode);
        $i = $produk->row_array();
        $data = array(
            'id'       => $i['product_code'],
            'name'     => $i['name'],
            'price'    => str_replace(",", "", $this->input->post('price')) - $this->input->post('disc'),
            'disc'     => $this->input->post('disc'),
            'qty'      => $this->input->post('qty'),
            'amount'      => str_replace(",", "", $this->input->post('price'))
        );
        if (!empty($this->cart->total_items())) {
            foreach ($this->cart->contents() as $items) {
                $id = $items['product_code'];
                $qtylama = $items['qty'];
                $rowid = $items['rowid'];
                $productcode = $this->input->post('product_code');
                $qty = $this->input->post('qty');
                if ($id == $productcode) {
                    $up = array(
                        'rowid' => $rowid,
                        'qty' => $qtylama + $qty
                    );
                    $this->cart->update($up);
                } else {
                    $this->cart->insert($data);
                }
            }
        } else {
            $this->cart->insert($data);
        }
        redirect('sales');
    }

    function remove()
    {
        $row_id = $this->uri->segment(3);
        $this->cart->update(array(
            'rowid'      => $row_id,
            'qty'     => 0
        ));
        redirect('sales');
    }
    function simpan_penjualan()
    {
        $total = $this->input->post('total');
        $jml_uang = str_replace(",", "", $this->input->post('jml_uang'));
        $kembalian = $jml_uang - $total;
        if (!empty($total) && !empty($jml_uang)) {
            if ($jml_uang < $total) {
                echo $this->session->set_flashdata('msg', '<label class="label label-danger">Jumlah Uang yang anda masukan Kurang</label>');
                redirect('sales');
            } else {
                $transaction_id = $this->sales->get_transaction_id();
                $this->session->set_userdata('transaction_id', $transaction_id);
                $order_proses = $this->sales->simpan_penjualan($transaction_id, $total, $jml_uang, $kembalian);
                if ($order_proses) {
                    $this->cart->destroy();

                    $this->session->unset_userdata('tglfak');
                    $this->session->unset_userdata('suplier');
                    redirect('sales');
                    // $this->load->view('admin/alert/alert_sukses');
                } else {
                    redirect('sales');
                }
            }
        } else {
            echo $this->session->set_flashdata('msg', '<label class="label label-danger">Penjualan Gagal di Simpan, Mohon Periksa Kembali Semua Inputan Anda!</label>');
            redirect('sales');
        }
    }

    function cetak_faktur()
    {
        $x['data'] = $this->sales->cetak_faktur();
        $this->load->view('admin/laporan/v_faktur', $x);
        //$this->session->unset_userdata('nofak');
    }

    function fetch()
    {
        echo $this->product->fetch_data($this->uri->segment(3));
    }
}
