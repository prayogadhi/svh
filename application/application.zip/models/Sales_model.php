<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sales_model extends CI_Model
{
    function simpan_penjualan($transaction_id, $total_price, $amount_paid, $change_money)
    {
        // $idadmin = $this->session->userdata('idadmin');
        $this->db->query("INSERT INTO sales (transaction_id,total_price,amount_paid,change_money) VALUES ('$transaction_id', '$total_price', '$amount_paid', '$change_money')");
        foreach ($this->cart->contents() as $item) {
            $data = array(
                'sales_transaction_id'  =>  $transaction_id,
                'sales_product_code'    =>  $item['id'],
                'sales_name'            =>  $item['name'],
                'sales_price'           =>  $item['price'],
                'sales_qty'             =>  $item['qty'],
                'sales_discount'        =>  $item['disc'],
                'sales_total'           =>  $item['subtotal']
            );
            $this->db->insert('sales_details', $data);
            $this->db->query("update product set stock=stock-'$item[qty]' where product_code='$item[id]'");
        }
        return true;
    }

    function tampil_sales()
    {
        $hsl = $this->db->query("SELECT * FROM sales");
        return $hsl;
    }

    function get_transaction_id()
    {
        $q = $this->db->query("SELECT MAX(RIGHT(transaction_id,6)) AS kd_max FROM sales WHERE DATE(date)=CURDATE()");
        $kd = "";
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $k) {
                $tmp = ((int) $k->kd_max) + 1;
                $kd = sprintf("%06s", $tmp);
            }
        } else {
            $kd = "000001";
        }
        return date('dmy') . $kd;
    }

    function cetak_faktur()
    {
        $nofak = $this->session->userdata('nofak');
        $hsl = $this->db->query("SELECT jual_nofak,DATE_FORMAT(jual_tanggal,'%d/%m/%Y %H:%i:%s') AS jual_tanggal,jual_total,jual_jml_uang,jual_kembalian,jual_keterangan,d_jual_barang_nama,d_jual_barang_satuan,d_jual_barang_harjul,d_jual_qty,d_jual_diskon,d_jual_total FROM tbl_jual JOIN tbl_detail_jual ON jual_nofak=d_jual_nofak WHERE jual_nofak='$nofak'");
        return $hsl;
    }
}
